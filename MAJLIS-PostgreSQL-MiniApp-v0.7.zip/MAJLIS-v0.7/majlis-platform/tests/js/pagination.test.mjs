import test from 'node:test';
import assert from 'node:assert/strict';
import {OrderPages} from '../../web/pagination.js';
import {escapeHtml,rublesToKopecks} from '../../web/ui.js';
const filters={q:'',bucket:'all'};
let orders=Array.from({length:305},(_,i)=>({id:305-i,item:'Original'}));
const page=query=>{const p=new URLSearchParams(query);const selected=orders.filter(o=>(!p.get('before')||o.id<Number(p.get('before')))&&(!p.get('q')||o.item.includes(p.get('q'))));return {user:{id:1,role:'buyer'},orders:selected.slice(0,100),next_cursor:selected.length>100?selected[99].id:null};};
test('several pages -> refresh -> continue, updated values and no duplicates',async()=>{
 const pages=new OrderPages(async query=>page(query));
 assert.equal((await pages.refresh(filters)).orders.length,100);
 assert.equal((await pages.more(filters)).orders.length,200);
 orders=orders.map(o=>({...o,item:'Updated'}));
 const refreshed=await pages.refresh(filters);assert.equal(refreshed.orders.length,200);assert.ok(refreshed.orders.every(o=>o.item==='Updated'));
 const next=await pages.more(filters);assert.equal(next.orders.length,300);assert.equal(new Set(next.orders.map(o=>o.id)).size,300);
 assert.equal((await pages.more(filters)).orders.length,305);
 assert.equal((await pages.refresh(filters)).orders.length,305);
 assert.equal((await pages.refresh({q:'Updated',bucket:'all'})).orders.length,100);
});
test('stale refresh cannot overwrite new filters',async()=>{
 let release;const delayed=new Promise(r=>release=r);let calls=0;
 const pages=new OrderPages(async query=>{if(++calls===1)await delayed;return page(query);});
 const old=pages.refresh(filters);const latest=await pages.refresh({q:'Missing',bucket:'all'});release();assert.equal(await old,null);assert.equal(latest.orders.length,0);assert.equal(pages.value.orders.length,0);
});
test('stale load-more cannot append into a new filter, double click deduplicated',async()=>{
 let release;const delayed=new Promise(r=>release=r);
 const pages=new OrderPages(async query=>{if(new URLSearchParams(query).has('before'))await delayed;return page(query);});
 await pages.refresh(filters);const old=pages.more(filters);assert.equal(await pages.more(filters),null);
 await pages.refresh({q:'Missing',bucket:'all'});release();assert.equal(await old,null);assert.equal(pages.value.orders.length,0);
});
test('HTML escaping and money are exact, invalid values rejected',()=>{
 assert.equal(escapeHtml('<img onerror="x">'), '&lt;img onerror=&quot;x&quot;&gt;');
 assert.equal(rublesToKopecks('120,01'),12001);
 for(const value of ['0','1.234','-1','Infinity'])assert.throws(()=>rublesToKopecks(value));
});

test('detail and transfer form escape personal fields and explain ownership',async()=>{
 const {detailView}=await import('../../web/order-detail.js');
 const stages=[{code:'confirmed',title:'Confirmed',description:'Description'}];
 const order={id:1,number:'<img src=x>',item:'<script>alert(1)</script>',customer_id:1,customer_name:'<img onerror="x">',amount:1,status:'confirmed',stage:stages[0],eta:'',shipment:'',events:[],payment_url:'',version:1};
 const buyer=detailView(order,stages,false,false);
 assert.ok(buyer.includes('&lt;script&gt;'));assert.ok(!buyer.includes('<script>'));assert.ok(!buyer.includes('details-form'));
 const manager=detailView(order,stages,true,false);
 assert.ok(manager.includes('transfer_confirmed'));assert.ok(manager.includes('&lt;img onerror=&quot;x&quot;&gt;'));assert.ok(manager.includes('customer_name'));
});

test('payment and ETA edits do not rewrite a checkpoint date',async()=>{
 const {detailView,eventTitle}=await import('../../web/order-detail.js');
 const stages=[{code:'confirmed',title:'Checkpoint',description:'Known'}];
 const order={id:1,number:'TEST',item:'Item',customer_id:1,customer_name:'Name',amount:12001,status:'confirmed',stage:stages[0],eta:'',shipment:'',payment_url:'https://payments.example/fake',events:[{id:1,status:'confirmed',kind:'status',created_at:'2026-10-01T10:00:00+03:00',source:'manager',note:''},{id:2,status:'confirmed',kind:'payment',created_at:'2026-10-14T10:00:00+03:00',source:'manager',note:''}]};
 const html=detailView(order,stages,true,true);
 const timeline=html.slice(html.indexOf('<ol'),html.indexOf('</ol>'));
 assert.ok(!timeline.includes('14 окт.'));
 assert.equal(eventTitle(order.events[1],stages),'Платёжная ссылка');
 assert.ok(html.includes('copy-payment')&&html.includes('revoke-payment')&&html.includes('commercial-form'));
 assert.ok(html.includes('120.01'));
});

test('separate workspaces hide role choices and discard stale page responses',async()=>{
 const {cabinetView}=await import('../../web/cabinets.js');
 assert.ok(!cabinetView({role:'buyer',available_cabinets:['buyer']}).includes('data-cabinet="manager"'));
 assert.ok(cabinetView({role:'manager',available_cabinets:['buyer','manager'],manager_all:false}).includes('Только назначенные'));
 assert.ok(!cabinetView({role:'manager',available_cabinets:['buyer','manager']}).includes('data-cabinet'));
 let release;const pending=new Promise(r=>release=r);
 const pages=new OrderPages(async query=>{const cabinet=new URLSearchParams(query).get('cabinet');if(cabinet==='manager')await pending;return {orders:[{id:cabinet==='manager'?10:20}],user:{id:1,role:cabinet},next_cursor:null};});
 const stale=pages.refresh({q:'',bucket:'all',cabinet:'manager'});pages.clear();
 await pages.refresh({q:'',bucket:'all',cabinet:'buyer'});release();
 assert.equal(await stale,null);assert.deepEqual(pages.value.orders,[{id:20}]);
});

test('tracking displays confirmed facts, escapes carrier/track, and labels old source data',async()=>{
 const {detailView}=await import('../../web/order-detail.js');
 const stages=[{code:'confirmed',title:'Confirmed',description:'Known'}];
 const order={id:1,number:'1',item:'Item',amount:12001,status:'confirmed',stage:stages[0],eta:'',shipment:'Batch',payment_url:'',events:[],updated_at:'2026-10-15T10:00:00Z',tracking:{number:'<script>',carrier:'<img onerror=x>',external_state:'stale',external_updated_at:'2026-10-01T10:00:00Z'}};
 const html=detailView(order,stages,false,false);
 assert.ok(html.includes('&lt;script&gt;')&&!html.includes('<script>'));
 assert.ok(html.includes('более 24 часов')&&html.includes('Статус оплаты: не подтверждён'));
 assert.ok(!html.includes('tracking-form'));
 assert.ok(detailView(order,stages,true,false).includes('tracking-form'));
});

test('manager inbox escapes client content and public cabinet has no manager entry',async()=>{
 const {feedView,supportForm}=await import('../../web/workspace.js');
 const {cabinetView}=await import('../../web/cabinets.js');
 const html=feedView('inbox',{items:[{id:1,customer_id:3001,first_name:'<img onerror=x>',text:'</p><script>alert(1)</script>',kind:'text',source:'miniapp',created_at:'2026-10-15T10:00:00Z'}]},[],()=>'<h1>Inbox</h1>');
 assert.ok(!html.includes('<script>')&&!html.includes('<img'));
 assert.ok(html.includes('&lt;script&gt;'));
 assert.ok(!cabinetView({role:'buyer',available_cabinets:['buyer','manager']}).includes('Менеджер'));
 assert.ok(!supportForm({text:'</textarea><script>'}).includes('</textarea><script>'));
});
